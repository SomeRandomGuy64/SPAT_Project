<?php

$url = "http://18.130.150.122/api/v1/utilities";
$json = file_get_contents($url);
$json_data = json_decode($json, true);

$data = [];
$data = $json_data['utilities'];

require_once ('../Views/utilities.phtml');
