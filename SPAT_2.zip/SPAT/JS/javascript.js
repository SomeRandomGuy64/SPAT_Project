function redirectToLoginPage() {
    location.replace("../Controllers/login.php")
}

function redirectToSignUpPage() {
    location.replace("../Controllers/signup.php")
}

function redirectToBuildings() {
    location.replace("../Controllers/buildings.php")
}
function redirectToInfrastructure() {
    location.replace("../Controllers/infrastructure.php")
}
function redirectToDemographics() {
    location.replace("../Controllers/demographics.php")
}
function redirectToUtilities() {
    location.replace("../Controllers/utilities.php")
}

function redirectToLogout() {
    location.replace("../index.php?logout")
}