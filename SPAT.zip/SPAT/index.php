
<?php

session_start();

    require_once ('Views/index.phtml');