<?php


ini_set('display_startup_errors',1);
ini_set('display_errors',1);
error_reporting(-1);


require_once ('../Models/Dataset.php');
$Dataset = new DataSet();


if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $baseEncodedPassword = base64_encode($password);
    $Dataset->signUp($username, $email, $baseEncodedPassword);
}


require_once ('../Views/signup.phtml');