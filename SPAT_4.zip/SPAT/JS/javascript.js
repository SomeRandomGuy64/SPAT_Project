function redirectToLoginPage() {
    location.replace("../Controllers/login.php")
}

function redirectToSignUpPage() {
    location.replace("../Controllers/signup.php")
}

function redirectToBuildings() {
    location.replace("../Controllers/buildings.php")
}
function redirectToInfrastructure() {
    location.replace("../Controllers/infrastructure.php")
}
function redirectToDemographics() {
    location.replace("../Controllers/demographics.php")
}
function redirectToUtilities() {
    location.replace("../Controllers/utilities.php")
}
function redirectToAddNewBuilding() {
    location.replace("../Controllers/addNewBuilding.php")
}

function redirectToAddNewInfrastructure() {
    location.replace("../Controllers/addNewInfrastructure.php")
}

function redirectToAddNewDemographics() {
    location.replace("../Controllers/addNewDemographics.php")
}

function redirectToAddNewUtilities() {
    location.replace("../Controllers/addNewUtilities.php")
}

function redirectToAllData() {
    location.replace("../Controllers/allData.php")
}

function redirectToLogout() {
    location.replace("../index.php?logout")
}