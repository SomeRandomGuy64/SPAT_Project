<?php
session_start();
$loggedIn = false;
if (!empty($_SESSION)) {
    $loggedIn = true;
} else {
    header('location: login.php');
}




if (isset($_POST['submit'])) {
    $postcode = $_POST['postcode'];
    $totalPopulation = $_POST['totalPopulation'];
    $totalElderly = $_POST['totalElderly'];
    $totalMobilityNeeds = $_POST['totalMobilityNeeds'];
    $totalHealthNeeds = $_POST['totalHealthNeeds'];

    $url = "http://18.130.150.122/api/v1/demographics";
//The data you want to send via POST
    $fields = [
        'postcode'      => $postcode,
        'totalPopulation'      => $totalPopulation,
        'totalElderly'      => $totalElderly,
        'totalMobilityNeeds'      => $totalMobilityNeeds,
        'totalHealthNeeds'      => $totalHealthNeeds
    ];

//url-ify the data for the POST
    $fields_string = http_build_query($fields);

//open connection
    $ch = curl_init();

//set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_POST, true);
    curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

//So that curl_exec returns the contents of the cURL; rather than echoing it
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);

//execute post
    $result = curl_exec($ch);
    header('location: demographics.php');
}

require_once ('../Views/header.phtml');
require_once ('../Views/addNewDemographics.phtml');
