<?php
session_start();
$loggedIn = false;
if (!empty($_SESSION)) {
    $loggedIn = true;
} else {
    header('location: login.php');
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $postcode = $_POST['postcode'];
    $type = $_POST['type'];
    $classification = $_POST['classification'];

    $url = "http://18.130.150.122/api/v1/utilities";
//The data you want to send via POST
    $fields = [
        'name'      => $name,
        'type'      => $type,
        'postcode'      => $postcode,
        'classification'      => $classification
    ];

//url-ify the data for the POST
    $fields_string = http_build_query($fields);

//open connection
    $ch = curl_init();

//set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_POST, true);
    curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

//So that curl_exec returns the contents of the cURL; rather than echoing it
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);

//execute post
    $result = curl_exec($ch);
    header('location: utilities.php');
}

require_once ('../Views/header.phtml');
require_once ('../Views/addNewUtilities.phtml');
