<?php
$link = "http://18.130.150.122/api/v1/infrastructure/";
$infrastructureId = $_GET['infrastructureId'];

$url = $link.$infrastructureId;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
header('location: infrastructure.php');