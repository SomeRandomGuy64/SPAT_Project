<?php
ini_set('display_startup_errors',1);
ini_set('display_errors',1);
error_reporting(-1);
//models (classes) required in this page
require_once ('Database.php');
//DatSet class created, to get data from the database
class DataSet {

    //global variables
    protected $_dbHandle, $_dbInstance;

    //class constructor, establishing database connection
    public function __construct() {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function signUp($username, $email, $password) {
        $sqlQuery = "INSERT INTO `users` VALUES (NULL, '" . $username . "', '" . $email . "', '" . $password . "')";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
    }

    public function checkUserCredentials($email, $password) {
        $sqlQuery = "SELECT COUNT(userId) FROM users WHERE email = '" . $email . "' AND password = '" . $password . "'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
        $checkCount = 0;
        while ($row = $statement->fetch()) {
            $checkCount = $row[0];
        }
        return $checkCount;
    }
}
