<?php
session_start();
if (empty($_SESSION)) {
    header('location: login.php');
}


$url = "http://18.130.150.122/api/v1/buildings";
$json = file_get_contents($url);
$json_data = json_decode($json, true);

$data = [];
$data = $json_data['buildings'];

require_once ('../Views/buildings.phtml');
